s = input()
if (s[0].lower()) ==(s[-1].lower()):
    print(1)
else:
    print(0)